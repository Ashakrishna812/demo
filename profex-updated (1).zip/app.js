// PROFEX - Updated JavaScript with Auto-Save Balance and Enhanced Features

// Application State
let appState = {
    user: {
        email: '',
        initialBalance: 20000,
        currentBalance: 20000,
        yourBalance: 0  // Will be calculated from profits only
    },
    profitEntries: [],
    expenseEntries: [],
    allocationItems: [],
    currentTab: 0,
    nextProfitId: 1,
    nextExpenseId: 1,
    nextAllocationId: 1
};

// Tab Configuration
const tabs = [
    { name: 'PROFIT', id: 'profitTab' },
    { name: 'EXPENSES', id: 'expensesTab' },
    { name: 'ALLOCATION', id: 'allocationTab' },
    { name: 'ANALYSIS', id: 'analysisTab' }
];

// Chart instances
let chartInstances = {
    profit: null,
    expense: null,
    comparison: null,
    allocation: null
};

// Auto-save timeout for balance input
let balanceAutoSaveTimeout = null;

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    console.log('App initializing...');
    try {
        initializeApp();
        setupEventListeners();
        console.log('App initialization completed successfully');
    } catch (error) {
        console.error('Error during app initialization:', error);
    }
});

function initializeApp() {
    // Show login screen initially
    const loginScreen = document.getElementById('loginScreen');
    const dashboardScreen = document.getElementById('dashboardScreen');
    
    if (loginScreen) {
        loginScreen.classList.remove('hidden');
        console.log('Login screen shown');
    }
    if (dashboardScreen) {
        dashboardScreen.classList.add('hidden');
        console.log('Dashboard screen hidden');
    }
    
    console.log('App initialized');
}

// ==================== LOCAL STORAGE FUNCTIONS ====================

function saveToLocalStorage() {
    try {
        const userKey = `profex_${appState.user.email}`;
        const dataToSave = {
            user: appState.user,
            profitEntries: appState.profitEntries,
            expenseEntries: appState.expenseEntries,
            allocationItems: appState.allocationItems,
            nextProfitId: appState.nextProfitId,
            nextExpenseId: appState.nextExpenseId,
            nextAllocationId: appState.nextAllocationId,
            lastUpdated: new Date().toISOString()
        };
        
        localStorage.setItem(userKey, JSON.stringify(dataToSave));
        console.log('Data saved to localStorage for user:', appState.user.email);
    } catch (error) {
        console.error('Error saving to localStorage:', error);
    }
}

function loadFromLocalStorage(email) {
    try {
        const userKey = `profex_${email}`;
        const savedData = localStorage.getItem(userKey);
        
        if (savedData) {
            const parsedData = JSON.parse(savedData);
            
            // Load all saved data
            appState.user = parsedData.user || appState.user;
            appState.profitEntries = parsedData.profitEntries || [];
            appState.expenseEntries = parsedData.expenseEntries || [];
            appState.allocationItems = parsedData.allocationItems || [];
            appState.nextProfitId = parsedData.nextProfitId || 1;
            appState.nextExpenseId = parsedData.nextExpenseId || 1;
            appState.nextAllocationId = parsedData.nextAllocationId || 1;
            
            console.log('Data loaded from localStorage for user:', email);
            return true;
        } else {
            console.log('No saved data found for user:', email);
            loadSampleDataForNewUser();
            return false;
        }
    } catch (error) {
        console.error('Error loading from localStorage:', error);
        loadSampleDataForNewUser();
        return false;
    }
}

function loadSampleDataForNewUser() {
    appState.profitEntries = [
        {
            id: 1,
            date: '2025-07-29',
            balance: 20000,
            investment: 1000,
            income: 1500,
            profit: 500
        }
    ];
    
    appState.expenseEntries = [
        {
            id: 1,
            date: '2025-07-29',
            balance: 20500,
            spent: 300,
            cumExp: 300
        }
    ];
    
    appState.allocationItems = [
        {
            id: 1,
            description: 'Electric Cycle',
            setAmount: 50000,
            dailyBasis: 1000,
            pending: 49500,
            priority: 1,
            allocated: 500
        },
        {
            id: 2,
            description: 'Grocery',
            setAmount: 7000,
            dailyBasis: 150,
            pending: 7000,
            priority: 2,
            allocated: 0
        },
        {
            id: 3,
            description: 'Entertainment',
            setAmount: 1000,
            dailyBasis: 170,
            pending: 1000,
            priority: 3,
            allocated: 0
        }
    ];
    
    appState.nextProfitId = 2;
    appState.nextExpenseId = 2;
    appState.nextAllocationId = 4;
    
    console.log('Sample data loaded for new user');
}

// ==================== EVENT LISTENERS ====================

function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    setTimeout(() => {
        // Login functionality
        const loginForm = document.getElementById('loginForm');
        const emailInput = document.getElementById('emailInput');
        
        if (loginForm && emailInput) {
            console.log('Login form and email input found, setting up listeners');
            
            loginForm.addEventListener('submit', function(e) {
                console.log('Form submit event triggered');
                handleLogin(e);
            });
            
            const loginButton = loginForm.querySelector('button[type="submit"]');
            if (loginButton) {
                loginButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    console.log('Login button clicked directly');
                    const email = emailInput.value.trim();
                    if (email && email.includes('@')) {
                        handleLoginDirect(email);
                    } else {
                        alert('Please enter a valid email address with @ symbol');
                        emailInput.focus();
                    }
                });
            }
            
            emailInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    console.log('Enter key pressed in email field');
                    const email = emailInput.value.trim();
                    if (email && email.includes('@')) {
                        handleLoginDirect(email);
                    } else {
                        alert('Please enter a valid email address with @ symbol');
                        emailInput.focus();
                    }
                }
            });
            
            console.log('Login form listeners added successfully');
        } else {
            console.error('Login form or email input not found');
        }
    }, 100);
    
    console.log('Initial event listeners setup complete');
}

// ==================== LOGIN FUNCTIONALITY ====================

function handleLogin(e) {
    console.log('handleLogin called via form submission');
    
    try {
        e.preventDefault();
        e.stopPropagation();
        
        const emailInput = document.getElementById('emailInput');
        const email = emailInput ? emailInput.value.trim() : '';
        
        console.log('Email entered via form:', email);
        
        if (email && email.length > 0 && email.includes('@')) {
            handleLoginDirect(email);
        } else {
            console.log('Email validation failed');
            alert('Please enter a valid email address with @ symbol');
            if (emailInput) {
                emailInput.focus();
            }
        }
    } catch (error) {
        console.error('Error in handleLogin:', error);
        alert('An error occurred during login. Please try again.');
    }
}

function handleLoginDirect(email) {
    console.log('handleLoginDirect called with email:', email);
    
    try {
        appState.user.email = email;
        
        // Load data from localStorage for this user
        const dataLoaded = loadFromLocalStorage(email);
        
        showDashboard();
        
        console.log('Login process completed successfully');
    } catch (error) {
        console.error('Error in handleLoginDirect:', error);
        alert('An error occurred during login. Please try again.');
    }
}

function showDashboard() {
    console.log('Showing dashboard');
    
    try {
        const loginScreen = document.getElementById('loginScreen');
        const dashboardScreen = document.getElementById('dashboardScreen');
        const userEmailDisplay = document.getElementById('userEmail');
        const editableBalanceInput = document.getElementById('editableBalance');
        
        if (loginScreen) {
            loginScreen.classList.add('hidden');
        }
        
        if (dashboardScreen) {
            dashboardScreen.classList.remove('hidden');
        }
        
        if (userEmailDisplay) {
            userEmailDisplay.textContent = appState.user.email;
        }
        
        if (editableBalanceInput) {
            editableBalanceInput.value = appState.user.initialBalance;
        }
        
        // Recalculate all balances and update displays
        recalculateAllData();
        updateBalanceDisplays();
        updateTabDisplay();
        renderAllTabs();
        
        // Setup dashboard listeners after showing dashboard
        setupDashboardListeners();
        
        console.log('Dashboard shown successfully');
    } catch (error) {
        console.error('Error in showDashboard:', error);
    }
}

function setupDashboardListeners() {
    console.log('Setting up dashboard listeners...');
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Logout button clicked');
            showLogoutModal();
        });
    }
    
    // Balance management - AUTO-SAVE Implementation
    const editableBalanceInput = document.getElementById('editableBalance');
    
    if (editableBalanceInput) {
        // Auto-save on input (every keystroke with debounce)
        editableBalanceInput.addEventListener('input', function(e) {
            console.log('Balance input changed:', e.target.value);
            
            // Clear existing timeout
            if (balanceAutoSaveTimeout) {
                clearTimeout(balanceAutoSaveTimeout);
            }
            
            // Set new timeout for auto-save after 500ms of no typing
            balanceAutoSaveTimeout = setTimeout(() => {
                autoSaveBalance();
            }, 500);
        });
        
        // Auto-save on blur (when user clicks away)
        editableBalanceInput.addEventListener('blur', function() {
            console.log('Balance input lost focus');
            if (balanceAutoSaveTimeout) {
                clearTimeout(balanceAutoSaveTimeout);
            }
            autoSaveBalance();
        });
        
        // Auto-save on Enter key
        editableBalanceInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                if (balanceAutoSaveTimeout) {
                    clearTimeout(balanceAutoSaveTimeout);
                }
                autoSaveBalance();
            }
        });
    }
    
    // Tab navigation
    const prevTabBtn = document.getElementById('prevTab');
    const nextTabBtn = document.getElementById('nextTab');
    
    if (prevTabBtn) {
        prevTabBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Previous tab clicked');
            navigateTab(-1);
        });
    }
    
    if (nextTabBtn) {
        nextTabBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Next tab clicked');
            navigateTab(1);
        });
    }
    
    // Tab dot navigation
    const tabDots = document.querySelectorAll('.tab-dot');
    tabDots.forEach((dot, index) => {
        dot.addEventListener('click', function() {
            appState.currentTab = index;
            updateTabDisplay();
            saveToLocalStorage();
        });
    });
    
    // Tab-specific buttons
    const addProfitBtn = document.getElementById('addProfitRow');
    const addExpenseBtn = document.getElementById('addExpenseRow');
    const addAllocationBtn = document.getElementById('addAllocationItem');
    const exportBtn = document.getElementById('exportBtn');
    
    if (addProfitBtn) {
        addProfitBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Add profit row clicked');
            addProfitRow();
        });
    }
    
    if (addExpenseBtn) {
        addExpenseBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Add expense row clicked');
            addExpenseRow();
        });
    }
    
    if (addAllocationBtn) {
        addAllocationBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Add allocation item clicked');
            showAllocationModal();
        });
    }
    
    if (exportBtn) {
        exportBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Export button clicked');
            exportData();
        });
    }
    
    // Modal functionality
    setupModalEvents();
    setupLogoutModalEvents();
    
    console.log('Dashboard event listeners setup complete');
}

// ==================== AUTO-SAVE BALANCE FUNCTIONALITY ====================

function autoSaveBalance() {
    const editableBalanceInput = document.getElementById('editableBalance');
    const newBalance = parseFloat(editableBalanceInput ? editableBalanceInput.value : 0) || 0;
    
    console.log('Auto-saving balance:', newBalance);
    
    appState.user.initialBalance = newBalance;
    
    // Recalculate everything
    recalculateAllData();
    updateBalanceDisplays();
    
    // Save to localStorage
    saveToLocalStorage();
    
    // Visual feedback for auto-save (optional)
    if (editableBalanceInput) {
        editableBalanceInput.style.borderColor = 'var(--color-success)';
        setTimeout(() => {
            editableBalanceInput.style.borderColor = '';
        }, 1000);
    }
    
    console.log('Balance auto-saved:', newBalance);
}

// ==================== LOGOUT FUNCTIONALITY ====================

function showLogoutModal() {
    const modal = document.getElementById('logoutModal');
    if (modal) {
        modal.classList.remove('hidden');
    }
}

function hideLogoutModal() {
    const modal = document.getElementById('logoutModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

function handleLogout() {
    console.log('Handling logout');
    
    try {
        // Save current data before logout
        saveToLocalStorage();
        
        // Clear form inputs
        clearAllForms();
        
        // Destroy charts
        destroyAllCharts();
        
        // Hide logout modal
        hideLogoutModal();
        
        // Show login screen
        showLoginScreen();
        
        console.log('Logout completed successfully');
    } catch (error) {
        console.error('Error during logout:', error);
    }
}

function clearAllForms() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.reset();
    }
    
    const allocationForm = document.getElementById('allocationForm');
    if (allocationForm) {
        allocationForm.reset();
    }
    
    const editableBalanceInput = document.getElementById('editableBalance');
    if (editableBalanceInput) {
        editableBalanceInput.value = '';
    }
}

function destroyAllCharts() {
    Object.keys(chartInstances).forEach(key => {
        if (chartInstances[key]) {
            chartInstances[key].destroy();
            chartInstances[key] = null;
        }
    });
}

function showLoginScreen() {
    const loginScreen = document.getElementById('loginScreen');
    const dashboardScreen = document.getElementById('dashboardScreen');
    
    if (dashboardScreen) {
        dashboardScreen.classList.add('hidden');
    }
    
    if (loginScreen) {
        loginScreen.classList.remove('hidden');
    }
    
    appState.currentTab = 0;
}

function setupLogoutModalEvents() {
    const closeLogoutModal = document.getElementById('closeLogoutModal');
    const cancelLogout = document.getElementById('cancelLogout');
    const confirmLogout = document.getElementById('confirmLogout');
    const logoutModal = document.getElementById('logoutModal');
    
    if (closeLogoutModal) {
        closeLogoutModal.addEventListener('click', hideLogoutModal);
    }
    
    if (cancelLogout) {
        cancelLogout.addEventListener('click', hideLogoutModal);
    }
    
    if (confirmLogout) {
        confirmLogout.addEventListener('click', handleLogout);
    }
    
    if (logoutModal) {
        logoutModal.addEventListener('click', function(e) {
            if (e.target === this) hideLogoutModal();
        });
    }
}

// ==================== BALANCE MANAGEMENT ====================

function updateBalanceDisplays() {
    const currentBalanceDisplay = document.getElementById('currentBalance');
    const yourBalanceDisplay = document.getElementById('yourBalance');
    
    if (currentBalanceDisplay) {
        currentBalanceDisplay.textContent = `₹${formatNumber(appState.user.currentBalance)}`;
    }
    
    if (yourBalanceDisplay) {
        yourBalanceDisplay.textContent = `₹${formatNumber(appState.user.yourBalance)}`;
    }
    
    console.log('Balance displays updated:', {
        currentBalance: appState.user.currentBalance,
        yourBalance: appState.user.yourBalance
    });
}

function calculateYourBalance() {
    // Get total profits earned
    const totalProfits = appState.profitEntries.reduce((sum, entry) => sum + entry.profit, 0);
    
    // Get total allocated amount from profits
    const totalAllocated = appState.allocationItems.reduce((sum, item) => sum + item.allocated, 0);
    
    // Your Balance = Total Profits - Total Allocated Amount (from profits only)
    appState.user.yourBalance = Math.max(0, totalProfits - totalAllocated);
    
    console.log('Your Balance calculated (Profits-based):', {
        totalProfits,
        totalAllocated,
        yourBalance: appState.user.yourBalance
    });
}

// ==================== ENHANCED TAB NAVIGATION ====================

function navigateTab(direction) {
    const newTab = appState.currentTab + direction;
    console.log('Navigating from tab', appState.currentTab, 'to tab', newTab);
    
    if (newTab >= 0 && newTab < tabs.length) {
        appState.currentTab = newTab;
        updateTabDisplay();
        saveToLocalStorage();
        console.log('Tab navigation successful to:', tabs[appState.currentTab].name);
    } else {
        console.log('Tab navigation failed - out of bounds');
    }
}

function updateTabDisplay() {
    console.log('Updating tab display to:', tabs[appState.currentTab].name);
    
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show current tab
    const currentTabElement = document.getElementById(tabs[appState.currentTab].id);
    if (currentTabElement) {
        currentTabElement.classList.add('active');
        console.log('Tab activated:', tabs[appState.currentTab].id);
    }
    
    // Update navigation
    const tabNameDisplay = document.getElementById('tabName');
    const prevTabBtn = document.getElementById('prevTab');
    const nextTabBtn = document.getElementById('nextTab');
    
    if (tabNameDisplay) {
        tabNameDisplay.textContent = tabs[appState.currentTab].name;
    }
    
    // Update tab dots
    const tabDots = document.querySelectorAll('.tab-dot');
    tabDots.forEach((dot, index) => {
        if (index === appState.currentTab) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
    
    if (prevTabBtn) {
        prevTabBtn.disabled = appState.currentTab === 0;
    }
    
    if (nextTabBtn) {
        nextTabBtn.disabled = appState.currentTab === tabs.length - 1;
    }
    
    // Render charts if on analysis tab
    if (appState.currentTab === 3) {
        setTimeout(renderAllCharts, 200);
    }
    
    console.log('Tab display updated successfully');
}

// ==================== PROFIT MANAGEMENT ====================

function addProfitRow() {
    console.log('Adding new profit row');
    
    const newEntry = {
        id: appState.nextProfitId++,
        date: getCurrentDate(),
        balance: appState.user.currentBalance,
        investment: 0,
        income: 0,
        profit: 0
    };
    
    appState.profitEntries.push(newEntry);
    renderProfitTable();
    saveToLocalStorage();
    
    console.log('Profit row added:', newEntry);
}

function renderProfitTable() {
    const tbody = document.getElementById('profitTableBody');
    if (!tbody) {
        console.log('Profit table body not found');
        return;
    }
    
    tbody.innerHTML = '';
    
    appState.profitEntries.forEach((entry) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="date" value="${entry.date}" onchange="updateProfitEntry(${entry.id}, 'date', this.value)"></td>
            <td><div class="auto-calculated">₹${formatNumber(entry.balance)}</div></td>
            <td><input type="number" value="${entry.investment}" onchange="updateProfitEntry(${entry.id}, 'investment', parseFloat(this.value) || 0)" placeholder="0"></td>
            <td><input type="number" value="${entry.income}" onchange="updateProfitEntry(${entry.id}, 'income', parseFloat(this.value) || 0)" placeholder="0"></td>
            <td><div class="auto-calculated">₹${formatNumber(entry.profit)}</div></td>
            <td><button class="delete-btn" onclick="deleteProfitEntry(${entry.id})">Delete</button></td>
        `;
        tbody.appendChild(row);
    });
    
    console.log('Profit table rendered with', appState.profitEntries.length, 'entries');
}

function updateProfitEntry(id, field, value) {
    console.log('Updating profit entry:', id, field, value);
    
    const entry = appState.profitEntries.find(e => e.id === id);
    if (entry) {
        entry[field] = value;
        if (field === 'investment' || field === 'income') {
            entry.profit = entry.income - entry.investment;
        }
        recalculateAllData();
        renderProfitTable();
        updateBalanceDisplays();
        processAllocation();
        saveToLocalStorage();
        
        console.log('Profit entry updated:', entry);
    }
}

function deleteProfitEntry(id) {
    console.log('Deleting profit entry:', id);
    
    appState.profitEntries = appState.profitEntries.filter(e => e.id !== id);
    recalculateAllData();
    renderProfitTable();
    updateBalanceDisplays();
    processAllocation();
    saveToLocalStorage();
}

function recalculateProfitBalances() {
    let runningBalance = appState.user.initialBalance;
    
    appState.profitEntries.forEach(entry => {
        entry.balance = runningBalance;
        entry.profit = entry.income - entry.investment;
        runningBalance += entry.profit;
    });
}

// ==================== EXPENSE MANAGEMENT ====================

function addExpenseRow() {
    console.log('Adding new expense row');
    
    const newEntry = {
        id: appState.nextExpenseId++,
        date: getCurrentDate(),
        balance: appState.user.currentBalance,
        spent: 0,
        cumExp: getTotalExpenses()
    };
    
    appState.expenseEntries.push(newEntry);
    renderExpenseTable();
    saveToLocalStorage();
}

function renderExpenseTable() {
    const tbody = document.getElementById('expenseTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    appState.expenseEntries.forEach((entry) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="date" value="${entry.date}" onchange="updateExpenseEntry(${entry.id}, 'date', this.value)"></td>
            <td><div class="auto-calculated">₹${formatNumber(entry.balance)}</div></td>
            <td><input type="number" value="${entry.spent}" onchange="updateExpenseEntry(${entry.id}, 'spent', parseFloat(this.value) || 0)" placeholder="0"></td>
            <td><div class="auto-calculated">₹${formatNumber(entry.cumExp)}</div></td>
            <td><button class="delete-btn" onclick="deleteExpenseEntry(${entry.id})">Delete</button></td>
        `;
        tbody.appendChild(row);
    });
}

function updateExpenseEntry(id, field, value) {
    const entry = appState.expenseEntries.find(e => e.id === id);
    if (entry) {
        entry[field] = value;
        recalculateAllData();
        renderExpenseTable();
        updateBalanceDisplays();
        saveToLocalStorage();
    }
}

function deleteExpenseEntry(id) {
    appState.expenseEntries = appState.expenseEntries.filter(e => e.id !== id);
    recalculateAllData();
    renderExpenseTable();
    updateBalanceDisplays();
    saveToLocalStorage();
}

function recalculateExpenseBalances() {
    let cumulativeExpenses = 0;
    
    appState.expenseEntries.forEach(entry => {
        cumulativeExpenses += entry.spent;
        entry.cumExp = cumulativeExpenses;
    });
}

function getTotalExpenses() {
    return appState.expenseEntries.reduce((total, entry) => total + entry.spent, 0);
}

// ==================== ALLOCATION MANAGEMENT ====================

function showAllocationModal() {
    const modal = document.getElementById('allocationModal');
    if (modal) {
        modal.classList.remove('hidden');
    }
}

function hideAllocationModal() {
    const modal = document.getElementById('allocationModal');
    const form = document.getElementById('allocationForm');
    
    if (modal) {
        modal.classList.add('hidden');
    }
    
    if (form) {
        form.reset();
    }
}

function setupModalEvents() {
    const closeModal = document.getElementById('closeModal');
    const cancelModal = document.getElementById('cancelModal');
    const allocationForm = document.getElementById('allocationForm');
    const allocationModal = document.getElementById('allocationModal');
    
    if (closeModal) {
        closeModal.addEventListener('click', hideAllocationModal);
    }
    
    if (cancelModal) {
        cancelModal.addEventListener('click', hideAllocationModal);
    }
    
    if (allocationForm) {
        allocationForm.addEventListener('submit', handleAllocationSubmit);
    }
    
    if (allocationModal) {
        allocationModal.addEventListener('click', function(e) {
            if (e.target === this) hideAllocationModal();
        });
    }
}

function handleAllocationSubmit(e) {
    e.preventDefault();
    
    const description = document.getElementById('itemDescription').value;
    const setAmount = parseFloat(document.getElementById('setAmount').value) || 0;
    const dailyBasis = parseFloat(document.getElementById('dailyBasis').value) || 0;
    
    const newItem = {
        id: appState.nextAllocationId++,
        description,
        setAmount,
        dailyBasis,
        pending: setAmount,
        priority: appState.allocationItems.length + 1,
        allocated: 0
    };
    
    appState.allocationItems.push(newItem);
    renderAllocationItems();
    processAllocation();
    hideAllocationModal();
    saveToLocalStorage();
}

function renderAllocationItems() {
    const container = document.getElementById('allocationContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    const sortedItems = [...appState.allocationItems].sort((a, b) => a.priority - b.priority);
    
    sortedItems.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'allocation-item';
        itemElement.draggable = true;
        itemElement.dataset.id = item.id;
        
        const progressPercentage = item.setAmount > 0 ? (item.allocated / item.setAmount) * 100 : 0;
        const dailyProgressPercentage = item.dailyBasis > 0 ? Math.min((item.allocated / item.dailyBasis) * 100, 100) : 0;
        
        let progressClass = 'low';
        if (dailyProgressPercentage >= 100) progressClass = 'high';
        else if (dailyProgressPercentage >= 50) progressClass = 'medium';
        
        itemElement.innerHTML = `
            <div class="allocation-header">
                <h4 class="allocation-title">${item.description}</h4>
                <div class="allocation-priority">Priority ${item.priority}</div>
            </div>
            <div class="allocation-details">
                <div class="allocation-detail">
                    <div class="allocation-detail-label">Set Amount</div>
                    <div class="allocation-detail-value">₹${formatNumber(item.setAmount)}</div>
                </div>
                <div class="allocation-detail">
                    <div class="allocation-detail-label">Daily Basis</div>
                    <div class="allocation-detail-value">₹${formatNumber(item.dailyBasis)}</div>
                </div>
                <div class="allocation-detail">
                    <div class="allocation-detail-label">Allocated</div>
                    <div class="allocation-detail-value">₹${formatNumber(item.allocated)}</div>
                </div>
                <div class="allocation-detail">
                    <div class="allocation-detail-label">Pending</div>
                    <div class="allocation-detail-value">₹${formatNumber(item.pending)}</div>
                </div>
            </div>
            <div class="allocation-progress">
                <div class="progress-bar">
                    <div class="progress-fill ${progressClass}" style="width: ${dailyProgressPercentage}%"></div>
                </div>
            </div>
            <div class="allocation-actions">
                <button class="delete-btn" onclick="deleteAllocationItem(${item.id})">Delete</button>
            </div>
        `;
        
        container.appendChild(itemElement);
    });
}

function deleteAllocationItem(id) {
    appState.allocationItems = appState.allocationItems.filter(item => item.id !== id);
    reorderPriorities();
    renderAllocationItems();
    processAllocation();
    saveToLocalStorage();
}

function reorderPriorities() {
    appState.allocationItems.forEach((item, index) => {
        item.priority = index + 1;
    });
}

function processAllocation() {
    const totalProfits = appState.profitEntries.reduce((sum, entry) => sum + entry.profit, 0);
    let remainingProfits = totalProfits;
    
    // Reset allocations
    appState.allocationItems.forEach(item => {
        item.allocated = 0;
        item.pending = item.setAmount;
    });
    
    // Sort by priority and allocate from profits
    const sortedItems = [...appState.allocationItems].sort((a, b) => a.priority - b.priority);
    
    for (const item of sortedItems) {
        if (remainingProfits <= 0) break;
        
        const allocateAmount = Math.min(remainingProfits, item.dailyBasis, item.pending);
        item.allocated += allocateAmount;
        item.pending = Math.max(0, item.setAmount - item.allocated);
        remainingProfits -= allocateAmount;
    }
    
    // Calculate Your Balance based on remaining profits after allocation
    calculateYourBalance();
    
    renderAllocationItems();
    updateBalanceDisplays();
}

// ==================== ANALYSIS AND CHARTS ====================

function renderAllCharts() {
    console.log('Rendering all charts...');
    renderProfitChart();
    renderExpenseChart();
    renderComparisonChart();
    renderAllocationChart();
}

function renderProfitChart() {
    const canvas = document.getElementById('profitChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    if (chartInstances.profit) {
        chartInstances.profit.destroy();
    }
    
    const labels = appState.profitEntries.map(entry => entry.date);
    const data = appState.profitEntries.map(entry => entry.profit);
    
    chartInstances.profit = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Profit',
                data: data,
                borderColor: '#1FB8CD',
                backgroundColor: 'rgba(31, 184, 205, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '₹' + formatNumber(value);
                        }
                    }
                }
            }
        }
    });
}

function renderExpenseChart() {
    const canvas = document.getElementById('expenseChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    if (chartInstances.expense) {
        chartInstances.expense.destroy();
    }
    
    const data = appState.expenseEntries.map(entry => entry.spent);
    const labels = appState.expenseEntries.map((entry, index) => `Expense ${index + 1}`);
    
    chartInstances.expense = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function renderComparisonChart() {
    const canvas = document.getElementById('comparisonChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    if (chartInstances.comparison) {
        chartInstances.comparison.destroy();
    }
    
    const labels = appState.profitEntries.map(entry => entry.date);
    const investmentData = appState.profitEntries.map(entry => entry.investment);
    const incomeData = appState.profitEntries.map(entry => entry.income);
    
    chartInstances.comparison = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Investment',
                data: investmentData,
                backgroundColor: '#B4413C'
            }, {
                label: 'Income',
                data: incomeData,
                backgroundColor: '#1FB8CD'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '₹' + formatNumber(value);
                        }
                    }
                }
            }
        }
    });
}

function renderAllocationChart() {
    const canvas = document.getElementById('allocationChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    if (chartInstances.allocation) {
        chartInstances.allocation.destroy();
    }
    
    const labels = appState.allocationItems.map(item => item.description);
    const allocated = appState.allocationItems.map(item => item.allocated);
    
    chartInstances.allocation = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                label: 'Allocated',
                data: allocated,
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// ==================== EXPORT FUNCTIONALITY ====================

function exportData() {
    const data = {
        user: appState.user,
        profitEntries: appState.profitEntries,
        expenseEntries: appState.expenseEntries,
        allocationItems: appState.allocationItems,
        summary: {
            totalProfit: appState.profitEntries.reduce((sum, entry) => sum + entry.profit, 0),
            totalExpenses: getTotalExpenses(),
            totalAllocated: appState.allocationItems.reduce((sum, item) => sum + item.allocated, 0)
        }
    };
    
    const csvContent = generateCSV(data);
    downloadCSV(csvContent, 'profex-financial-report.csv');
}

function generateCSV(data) {
    let csv = 'PROFEX Financial Report\n\n';
    
    csv += `User Email,${data.user.email}\n`;
    csv += `Initial Balance,₹${formatNumber(data.user.initialBalance)}\n`;
    csv += `Current Balance,₹${formatNumber(data.user.currentBalance)}\n`;
    csv += `Your Balance,₹${formatNumber(data.user.yourBalance)}\n\n`;
    
    csv += 'PROFIT ENTRIES\n';
    csv += 'Date,Balance,Investment,Income,Profit\n';
    data.profitEntries.forEach(entry => {
        csv += `${entry.date},₹${formatNumber(entry.balance)},₹${formatNumber(entry.investment)},₹${formatNumber(entry.income)},₹${formatNumber(entry.profit)}\n`;
    });
    csv += '\n';
    
    csv += 'EXPENSE ENTRIES\n';
    csv += 'Date,Balance,Spent,Cumulative Expenses\n';
    data.expenseEntries.forEach(entry => {
        csv += `${entry.date},₹${formatNumber(entry.balance)},₹${formatNumber(entry.spent)},₹${formatNumber(entry.cumExp)}\n`;
    });
    csv += '\n';
    
    csv += 'ALLOCATION ITEMS\n';
    csv += 'Description,Set Amount,Daily Basis,Allocated,Pending,Priority\n';
    data.allocationItems.forEach(item => {
        csv += `${item.description},₹${formatNumber(item.setAmount)},₹${formatNumber(item.dailyBasis)},₹${formatNumber(item.allocated)},₹${formatNumber(item.pending)},${item.priority}\n`;
    });
    csv += '\n';
    
    csv += 'SUMMARY\n';
    csv += `Total Profit,₹${formatNumber(data.summary.totalProfit)}\n`;
    csv += `Total Expenses,₹${formatNumber(data.summary.totalExpenses)}\n`;
    csv += `Total Allocated,₹${formatNumber(data.summary.totalAllocated)}\n`;
    
    return csv;
}

function downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

// ==================== UTILITY FUNCTIONS ====================

function getCurrentDate() {
    return new Date().toISOString().split('T')[0];
}

function formatNumber(num) {
    return new Intl.NumberFormat('en-IN').format(num);
}

function recalculateAllData() {
    recalculateProfitBalances();
    recalculateExpenseBalances();
    
    // Calculate current balance: Initial + Profits - Expenses
    const totalProfits = appState.profitEntries.reduce((sum, entry) => sum + entry.profit, 0);
    const totalExpenses = getTotalExpenses();
    appState.user.currentBalance = appState.user.initialBalance + totalProfits - totalExpenses;
    
    processAllocation();
    calculateYourBalance();
    renderAllTabs();
}

function renderAllTabs() {
    renderProfitTable();
    renderExpenseTable();
    renderAllocationItems();
}

// ==================== GLOBAL FUNCTIONS FOR INLINE HANDLERS ====================

window.updateProfitEntry = updateProfitEntry;
window.deleteProfitEntry = deleteProfitEntry;
window.updateExpenseEntry = updateExpenseEntry;
window.deleteExpenseEntry = deleteExpenseEntry;
window.deleteAllocationItem = deleteAllocationItem;